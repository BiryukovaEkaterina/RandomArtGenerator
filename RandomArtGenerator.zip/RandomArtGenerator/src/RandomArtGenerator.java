import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class RandomArtGenerator {
    private int numOfFigures;
    private Rectangle coordinateArea;
    private boolean isDense;

    public RandomArtGenerator(int numOfFigures, Rectangle coordinateArea, boolean isDense) {
        this.numOfFigures = numOfFigures;
        this.coordinateArea = coordinateArea;
        this.isDense = isDense;
    }

    public void generateRandomArt() {
        JFrame frame = new JFrame("Random Art Generator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setLayout(new BorderLayout());

        JPanel artPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;

                // Отрисовка координатной сетки
                drawCoordinateGrid(g2d);

                // Генерация случайных фигур
                Random random = new Random();
                for (int i = 0; i < numOfFigures; i++) {
                    int x = random.nextInt(coordinateArea.width);
                    int y = random.nextInt(coordinateArea.height);
                    int width = random.nextInt(50) + 10;
                    int height = random.nextInt(50) + 10;

                    if (isDense) {
                        x = x / 10 * 10; // Округление координат до ближайшей десятки
                        y = y / 10 * 10;
                    } else {
                        boolean isIntersecting = checkIntersection(x, y, width, height);
                        while (isIntersecting) {
                            x = random.nextInt(coordinateArea.width);
                            y = random.nextInt(coordinateArea.height);
                            isIntersecting = checkIntersection(x, y, width, height);
                        }
                    }

                    int figureType = random.nextInt(6);
                    switch (figureType) {
                        case 0:
                            g2d.drawLine(x, y, x + width, y + height);
                            break;
                        case 1:
                            g2d.drawOval(x, y, width, height);
                            break;
                        case 2:
                            g2d.drawRect(x, y, width, height);
                            break;
                        case 3:
                            int[] xPoints = {x, x + width / 2, x + width};
                            int[] yPoints = {y + height, y, y + height};
                            g2d.drawPolygon(xPoints, yPoints, 3);
                            break;
                        case 4:
                            g2d.drawArc(x, y, width, height, 0, 180);
                            break;
                        case 5:
                            int[] xPoints2 = {x, x + width, x + width / 2, x + width / 4 * 3, x + width / 4};
                            int[] yPoints2 = {y, y, y + height, y + height, y + height};
                            g2d.drawPolygon(xPoints2, yPoints2, 5);
                            break;
                    }
                }
            }

            private void drawCoordinateGrid(Graphics2D g2d) {
                int gridSize = 10;

                g2d.setColor(Color.LIGHT_GRAY);

                // Вертикальные линии
                for (int x = coordinateArea.x; x <= coordinateArea.x + coordinateArea.width; x += gridSize) {
                    g2d.drawLine(x, coordinateArea.y, x, coordinateArea.y + coordinateArea.height);
                }

                // Горизонтальные линии
                for (int y = coordinateArea.y; y <= coordinateArea.y + coordinateArea.height; y += gridSize) {
                    g2d.drawLine(coordinateArea.x, y, coordinateArea.x + coordinateArea.width, y);
                }

                g2d.setColor(Color.BLACK);
            }

            private boolean checkIntersection(int x, int y, int width, int height) {
                for (Component component : getComponents()) {
                    if (component instanceof Shape) {
                        Shape shape = (Shape) component;
                        Rectangle shapeBounds = shape.getBounds();
                        if (shapeBounds.intersects(x, y, width, height)) {
                            return true;
                        }
                    }
                }
                return false;
            }
        };

        frame.add(artPanel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        // Окно с вопросом:
        String input = JOptionPane.showInputDialog("Укажите количество фигур:");
        int numOfFigures = Integer.parseInt(input);

        // Окно с указанием области координат
        input = JOptionPane.showInputDialog("Укажите область координат через запятую (x, y):");
        String[] coordinates = input.split(",");
        int x = Integer.parseInt(coordinates[0].trim());
        int y = Integer.parseInt(coordinates[1].trim());
        int width = 500;
        int height = 500;
        Rectangle coordinateArea = new Rectangle(x, y, width, height);

        // Окно с указанием кучности фигур
        input = JOptionPane.showInputDialog("Укажите кучность фигур (Близко/Отдаленно):");
        boolean isDense = input.equalsIgnoreCase("Близко");

        RandomArtGenerator generator = new RandomArtGenerator(numOfFigures, coordinateArea, isDense);
        generator.generateRandomArt();
    }
}
